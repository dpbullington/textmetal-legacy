﻿#region Using

using System;

#endregion

namespace NMockTests._TestStructures
{
	public class ReturnValue : IamAreturnValue
	{
		#region Implementation of IamAreturnValue

		public void SayHi()
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}