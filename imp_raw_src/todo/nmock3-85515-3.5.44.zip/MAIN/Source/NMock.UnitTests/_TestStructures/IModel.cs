﻿namespace NMockTests
{
	public interface IModel
	{
		int GetCount(string searchText);
	}
}