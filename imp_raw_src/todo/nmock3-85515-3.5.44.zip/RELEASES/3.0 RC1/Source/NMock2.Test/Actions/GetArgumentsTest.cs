
using System;
using NUnit.Framework;

namespace NMock2.Test.Actions
{
    [TestFixture]
    public class GetArgumentsTest
    {
       
        /// <summary>
        /// GetArguments can be used to simulate call back from mocked dependance object
        /// </summary>
        [Test]
        public void ShouldGetArgumentsOfInvokedMethod()
        {
            Mockery mocks = new Mockery();
            string message = "hello";
            IMessageService serviceMock = mocks.NewMock<IMessageService>();

            MessageController controller = new MessageController(serviceMock);

            Expect.Once.On(serviceMock).Method("GetMessage").With(Is.EqualTo(23), Is.Anything)
                    .Will(GetArguments.WhenCalled(arguments => (arguments[1] as Action<string>).Invoke(message)));

            controller.GetMessage(23);

            Assert.AreEqual(message, controller.Message);
        }


        public interface IMessageService
        {
            void GetMessage(int id, Action<string> responseHandler);
        }

        public class MessageController
        {
            private IMessageService service;
            private string message;

            public MessageController(IMessageService service)
            {
                this.service = service;
            }

            public string Message
            {
                get { return message; }
            }

            public void GetMessage(int id)
            {
                service.GetMessage(id, response => message = response);
            }
        }

    }
}