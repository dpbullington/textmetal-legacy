﻿using System.Security;

//For some odd reason, it behaves different in a win2k3 box.
//[assembly: AllowPartiallyTrustedCallers]
//[assembly: SecurityTransparent]