// *********************************************************************
// Copyright 2007, Andreas Schlapsi
// This is free software licensed under the MIT license. 
// *********************************************************************
using System;

namespace NUnitExtension.RowTest
{
	public enum SpecialValue
	{
		Null = 1
	}
}
