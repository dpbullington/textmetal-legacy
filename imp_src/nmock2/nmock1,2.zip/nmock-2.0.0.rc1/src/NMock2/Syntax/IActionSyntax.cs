namespace NMock2.Syntax
{
	public interface IActionSyntax
	{
		void Will(params IAction[] actions);
	}
}
