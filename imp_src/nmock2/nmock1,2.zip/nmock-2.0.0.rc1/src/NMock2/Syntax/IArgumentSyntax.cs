namespace NMock2.Syntax
{
	public interface IArgumentSyntax : IMatchSyntax
	{
		IMatchSyntax With(params Matcher[] otherArgumentMatchers);
		IMatchSyntax With(params object[] equalArgumentValues);
		IMatchSyntax WithNoArguments();
		IMatchSyntax WithAnyArguments();
	}
}
