namespace NMock2.Syntax
{
	public interface IReceiverSyntax
	{
		IMethodSyntax On(object o);
	}
}
