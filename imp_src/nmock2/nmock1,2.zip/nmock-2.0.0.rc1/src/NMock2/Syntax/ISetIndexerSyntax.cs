namespace NMock2.Syntax
{
    public interface ISetIndexerSyntax
    {
        IValueSyntax this[params Matcher[] args] { get; }
        IValueSyntax this[params object[] args] { get; }
    }
}
