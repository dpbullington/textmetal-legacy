namespace NMock2.Monitoring
{
	public interface IInvokable
	{
		void Invoke( Invocation invocation );
	}
}
