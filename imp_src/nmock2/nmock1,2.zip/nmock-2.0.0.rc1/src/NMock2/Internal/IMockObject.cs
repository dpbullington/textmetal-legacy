namespace NMock2.Internal
{
	public interface IMockObject
	{
		bool HasMethodMatching(Matcher methodMatcher);
		void AddExpectation(IExpectation expectation);
	}
}
