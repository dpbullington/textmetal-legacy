using System;
using System.Collections;
using System.IO;
using NMock2.Monitoring;

namespace NMock2.Internal
{
	public class UnorderedExpectations : IExpectationOrdering
	{
		private ArrayList expectations = new ArrayList();
		private int depth;
		private string prompt;

		public UnorderedExpectations()
		{
			this.depth = 0;
			this.prompt = "Expected:";
		}

		public UnorderedExpectations(int depth)
		{
			this.depth = depth;
			this.prompt = "Unordered:";
		}

		public bool IsActive
		{
			get
			{
				foreach (IExpectation e in expectations)
				{
					if (e.IsActive) return true;
				}
				return false;
			}
		}
		
		public bool HasBeenMet
		{
			get
			{
				foreach (IExpectation e in expectations)
				{
					if (!e.HasBeenMet) return false;
				}
				return true;
			}
		}
		
		public bool Matches(Invocation invocation)
		{
			foreach (IExpectation e in expectations)
			{
				if (e.Matches(invocation)) return true;
			}
			return false;
		}
		
		public void Perform(Invocation invocation)
		{
			foreach (IExpectation e in expectations)
			{
				if (e.Matches(invocation))
				{
					e.Perform(invocation);
					return;
				}
			}

			throw new InvalidOperationException("No matching expectation");
		}

		public void DescribeActiveExpectationsTo(TextWriter writer)
		{
			writer.WriteLine(prompt);
			foreach (IExpectation expectation in expectations)
			{
				if (expectation.IsActive)
				{
					Indent(writer, depth+1);
					expectation.DescribeActiveExpectationsTo(writer);
					writer.WriteLine();
				}
			}
		}

		public void DescribeUnmetExpectationsTo(TextWriter writer)
		{
			writer.WriteLine(prompt);
			foreach (IExpectation expectation in expectations)
			{
				if (!expectation.HasBeenMet)
				{
					Indent(writer, depth+1);
					expectation.DescribeUnmetExpectationsTo(writer);
					writer.WriteLine();
				}
			}
		}

		private void Indent(TextWriter writer, int n)
		{
			for (int i = 0; i < n; i++) writer.Write("  ");
		}

		public void AddExpectation(IExpectation expectation)
		{
			expectations.Add(expectation);
		}
	}
}
