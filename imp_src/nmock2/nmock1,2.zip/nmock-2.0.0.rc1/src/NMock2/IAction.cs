using NMock2.Monitoring;

namespace NMock2
{
	public interface IAction : IInvokable, ISelfDescribing
	{
	}
}

