using NUnit.Framework;

namespace NMock2.AcceptanceTests
{
	[TestFixture]
	public class EventsAcceptanceTest
	{
		public delegate void Listener(string message);

		public interface Announcer
		{
			event Listener Listeners;
		}
		
		public void DummyListener(string message)
		{
		}
		
		[Test]
		public void CanExpectEventAdd()
		{
			Mockery mocks = new Mockery();
			Announcer announcer = (Announcer) mocks.NewMock(typeof(Announcer));

			Expect.Once.On(announcer).EventAdd("Listeners", new Listener(DummyListener));
			
			announcer.Listeners += new Listener(DummyListener);

			mocks.VerifyAllExpectationsHaveBeenMet();
		}
		
		[Test]
		public void CanExpectEventRemove()
		{
			Mockery mocks = new Mockery();
			Announcer announcer = (Announcer) mocks.NewMock(typeof(Announcer));
			
			Expect.Once.On(announcer).EventRemove("Listeners", new Listener(DummyListener));
			
			announcer.Listeners -= new Listener(DummyListener);
			
			mocks.VerifyAllExpectationsHaveBeenMet();
		}
		
		[Test]
		public void DelegatesCanBeComparedToEquality()
		{
			Listener l1 = new Listener(DummyListener);
			Listener l2 = new Listener(DummyListener);

			Assert.AreEqual(l1, l2);
		}
	}
}
