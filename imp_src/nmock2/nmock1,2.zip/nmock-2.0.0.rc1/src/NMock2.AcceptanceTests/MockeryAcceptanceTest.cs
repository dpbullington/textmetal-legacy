using NUnit.Framework;
using System;

namespace NMock2.AcceptanceTests
{
	[TestFixture]
	public class MockeryAcceptanceTest
	{
		[Test]
		public void CallingVerifyOnMockeryShouldEnableMockeryToBeUsedSuccessfullyForOtherTests()
		{
			Mockery mocks = new Mockery();
			IMockedType mockWithUninvokedExpectations = (IMockedType) mocks.NewMock(typeof(IMockedType));
			Expect.Once.On(mockWithUninvokedExpectations).Method("Method").WithNoArguments();
			try
			{
				mocks.VerifyAllExpectationsHaveBeenMet();
				Assert.Fail("Expected ExpectationException to be thrown");
			}
			catch(NMock2.Internal.ExpectationException expected)
			{
				Assert.IsTrue(expected.Message.IndexOf("not all expected invocations were performed") != -1);
			}
			
			IMockedType mockWithInvokedExpectations = (IMockedType) mocks.NewMock(typeof(IMockedType));
			Expect.Once.On(mockWithInvokedExpectations).Method("Method").WithNoArguments();
			mockWithInvokedExpectations.Method();
			mocks.VerifyAllExpectationsHaveBeenMet();
		}
	}
	
	public interface IMockedType
	{
		void Method();
	}
}
