This "config" file is adjusted to support "auto-props" with TortoiseSVN.

Usually you will find your local "config" file in the folder
C:\Documents and Settings\%USERNAME%\Application Data\Subversion\

