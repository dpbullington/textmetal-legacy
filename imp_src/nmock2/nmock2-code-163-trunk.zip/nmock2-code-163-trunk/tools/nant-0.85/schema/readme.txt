
VS2005: Copy schema file to 

  C:\Program Files\Microsoft Visual Studio 8\Xml\Schemas\

to use IntelliSense