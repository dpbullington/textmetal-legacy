copy the code snippets to

Windows Vista:
C:\Users\%USERNAME%\Documents\Visual Studio 2008\Code Snippets\Visual C#\My Code Snippets\

or your similar folder under Windows XP.