﻿namespace System.Text
{
    public class SerializableAttribute : Attribute
    {
         
    }
}