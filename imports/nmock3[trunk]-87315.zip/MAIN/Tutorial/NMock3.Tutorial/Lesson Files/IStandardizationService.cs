﻿namespace NMock3.Tutorial
{
	public interface IStandardizationService
	{
		Phone StandardizePhone(Phone phone);
		Address StandardizeAddress(Address address);
	}
}
