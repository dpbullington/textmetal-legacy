﻿namespace NMockTests._TestStructures
{
	public class TestingMockObjectFactoryB : TestingMockObjectFactoryA
	{
	}
}