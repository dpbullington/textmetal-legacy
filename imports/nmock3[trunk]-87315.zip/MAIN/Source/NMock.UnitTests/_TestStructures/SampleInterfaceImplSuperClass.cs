﻿namespace NMockTests._TestStructures
{
	public class SampleInterfaceImplSuperClass
	{
		// non-virtual impl of interface method declared
		// at a differnt level of inheritance heirarchy
		public int SomeOtherMethod()
		{
			return 3;
		}
	}
}