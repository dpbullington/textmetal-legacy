﻿namespace NMockTests._TestStructures
{
	public class Inner
	{
		public string CONST = "Constant1";

		public string Prop { get; set; }

		public string GetString()
		{
			return "Method";
		}
	}
}