﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace NUnit.TestData.AssertMultipleData
{
    // NOTE: Some of these methods were getting optimized out of
    // existence in the .NET 2.0 AppVeyor build. For that reason,
    // we turned optimization off for the testdata assembly.

    public class AssertMultipleFixture
    {
        private static readonly ComplexNumber complex = new ComplexNumber(5.2, 3.9);

        [Test]
        public void EmptyBlock()
        {
            Assert.Multiple(() => { });
        }

        [Test]
        public void SingleAssertSucceeds()
        {
            Assert.Multiple(() =>
            {
                Assert.That(2 + 2, Is.EqualTo(4));
            });
        }

        [Test]
        public void TwoAssertsSucceed()
        {
            Assert.Multiple(() =>
            {
                Assert.That(complex.RealPart, Is.EqualTo(5.2));
                Assert.That(complex.ImaginaryPart, Is.EqualTo(3.9));
            });
        }

        [Test]
        public void ThreeAssertsSucceed()
        {
            Assert.Multiple(() =>
            {
                Assert.That(2 + 2, Is.EqualTo(4));
                Assert.That(complex.RealPart, Is.EqualTo(5.2));
                Assert.That(complex.ImaginaryPart, Is.EqualTo(3.9));
            });
        }

        [Test]
        public void NestedBlock_ThreeAssertsSucceed()
        {
            Assert.Multiple(() =>
            {
                Assert.That(2 + 2, Is.EqualTo(4));

                Assert.Multiple(() =>
                {
                    Assert.That(complex.RealPart, Is.EqualTo(5.2));
                    Assert.That(complex.ImaginaryPart, Is.EqualTo(3.9));
                });
            });
        }

        [Test]
        public void TwoNestedBlocks_ThreeAssertsSucceed()
        {
            Assert.Multiple(() =>
            {
                Assert.Multiple(() =>
                {
                    Assert.That(2 + 2, Is.EqualTo(4));
                });

                Assert.Multiple(() =>
                {
                    Assert.That(complex.RealPart, Is.EqualTo(5.2));
                    Assert.That(complex.ImaginaryPart, Is.EqualTo(3.9));
                });
            });
        }

        [Test]
        public void NestedBlocksInMethodCalls()
        {
            SingleAssertSucceeds();
            TwoAssertsSucceed();
        }

        [Test]
        public void MethodCallsFail()
        {
            Assert.Multiple(() =>
            {
                Assert.Fail("Message from Assert.Fail");
            });
        }

        [Test]
        public void MethodCallsFailAfterTwoAssertsFail()
        {
            Assert.Multiple(() =>
            {
                Assert.That(complex.RealPart, Is.EqualTo(5.0), "RealPart");
                Assert.That(complex.ImaginaryPart, Is.EqualTo(4.2), "ImaginaryPart");
                Assert.Fail("Message from Assert.Fail");
            });
        }

        [Test]
        public void TwoAsserts_FirstAssertFails()
        {
            Assert.Multiple(() =>
            {
                Assert.That(complex.RealPart, Is.EqualTo(5.0), "RealPart");
                Assert.That(complex.ImaginaryPart, Is.EqualTo(3.9), "ImaginaryPart");
            });
        }

        [Test]
        public void TwoAsserts_SecondAssertFails()
        {
            Assert.Multiple(() =>
            {
                Assert.That(complex.RealPart, Is.EqualTo(5.2), "RealPart");
                Assert.That(complex.ImaginaryPart, Is.EqualTo(4.2), "ImaginaryPart");
            });
        }

        [Test]
        public void TwoAsserts_BothAssertsFail()
        {
            Assert.Multiple(() =>
            {
                Assert.That(complex.RealPart, Is.EqualTo(5.0), "RealPart");
                Assert.That(complex.ImaginaryPart, Is.EqualTo(4.2), "ImaginaryPart");
            });
        }

        [Test]
        public void NestedBlock_FirstAssertFails()
        {
            Assert.Multiple(() =>
            {
                Assert.That(2 + 2, Is.EqualTo(5));

                Assert.Multiple(() =>
                {
                    Assert.That(complex.RealPart, Is.EqualTo(5.2), "RealPart");
                    Assert.That(complex.ImaginaryPart, Is.EqualTo(3.9), "ImaginaryPart");
                });
            });
        }

        [Test]
        public void NestedBlock_TwoAssertsFail()
        {
            Assert.Multiple(() =>
            {
                Assert.That(2 + 2, Is.EqualTo(5));

                Assert.Multiple(() =>
                {
                    Assert.That(complex.RealPart, Is.EqualTo(5.2), "RealPart");
                    Assert.That(complex.ImaginaryPart, Is.EqualTo(4.2), "ImaginaryPart");
                });
            });
        }

        [Test]
        public void TwoNestedBlocks_FirstAssertFails()
        {
            Assert.Multiple(() =>
            {
                Assert.Multiple(() =>
                {
                    Assert.That(2 + 2, Is.EqualTo(5));
                });

                Assert.Multiple(() =>
                {
                    Assert.That(complex.RealPart, Is.EqualTo(5.2), "RealPart");
                    Assert.That(complex.ImaginaryPart, Is.EqualTo(3.9), "ImaginaryPart");
                });
            });
        }

        [Test]
        public void TwoNestedBlocks_TwoAssertsFail()
        {
            Assert.Multiple(() =>
            {
                Assert.Multiple(() =>
                {
                    Assert.That(2 + 2, Is.EqualTo(5));
                });

                Assert.Multiple(() =>
                {
                    Assert.That(complex.RealPart, Is.EqualTo(5.2), "RealPart");
                    Assert.That(complex.ImaginaryPart, Is.EqualTo(4.2), "ImaginaryPart");
                });
            });
        }

        [Test]
        public void ExceptionThrown()
        {
            Assert.Multiple(() =>
            {
                throw new Exception("Simulated Error");
            });
        }

        [Test]
        public void ExceptionThrownAfterTwoFailures()
        {
            Assert.Multiple(() =>
            {
                Assert.AreEqual(5, 2 + 2, "Failure 1");
                Assert.True(1 == 0, "Failure 2");
                throw new Exception("Simulated Error");
            });
        }

        [Test]
        public void AssertPassInBlock()
        {
            Assert.Multiple(() =>
            {
                Assert.Pass("Message from Assert.Pass");
            });
        }

        [Test]
        public void AssertIgnoreInBlock()
        {
            Assert.Multiple(() =>
            {
                Assert.Ignore("Message from Assert.Ignore");
            });
        }

        [Test]
        public void AssertInconclusiveInBlock()
        {
            Assert.Multiple(() =>
            {
                Assert.Inconclusive("Message from Assert.Inconclusive");
            });
        }

        [Test]
        public void AssumptionInBlock()
        {
            Assert.Multiple(() =>
            {
                Assume.That(2 + 2 == 4);
            });
        }
    }

    class ComplexNumber
    {
        public ComplexNumber(double realPart, double imaginaryPart)
        {
            RealPart = realPart;
            ImaginaryPart = imaginaryPart;
        }

        public double RealPart;
        public double ImaginaryPart;
    }
}
