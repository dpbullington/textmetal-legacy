﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;
using OpenCover.Framework;

namespace OpenCover.Test.Framework
{
    [TestFixture]
    public class ProfilerRegistrationTests
    {
       // Can we test this? Having trouble thinking of a test 
       // that would work under nunit (which can shadow copy files)
    }
}
