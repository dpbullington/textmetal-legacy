//
// OpenCover - S Wilde
//
// This source code is released under the MIT License; see the accompanying license file.
//
// stdafx.cpp : source file that includes just the standard includes
// OpenCover.Profiler.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
