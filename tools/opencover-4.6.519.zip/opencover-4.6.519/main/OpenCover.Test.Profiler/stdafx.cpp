// stdafx.cpp : source file that includes just the standard includes
// OpenCover.Test.Profiler.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file


// The following lines pull in the real gtest *.cc files.
#include "..\..\tools\gtest-1.6.0\src\gtest.cc"
#include "..\..\tools\gtest-1.6.0\src\gtest-death-test.cc"
#include "..\..\tools\gtest-1.6.0\src\gtest-filepath.cc"
#include "..\..\tools\gtest-1.6.0\src\gtest-port.cc"
#include "..\..\tools\gtest-1.6.0\src\gtest-printers.cc"
#include "..\..\tools\gtest-1.6.0\src\gtest-test-part.cc"
#include "..\..\tools\gtest-1.6.0\src\gtest-typed-test.cc"

#include "..\..\tools\gtest-1.6.0\src\gtest_main.cc"