﻿namespace TargetFakes
{
    public static class MyStaticClass
    {
        public static int MyStaticMethod()
        {
            return 42;
        }
    }
}
