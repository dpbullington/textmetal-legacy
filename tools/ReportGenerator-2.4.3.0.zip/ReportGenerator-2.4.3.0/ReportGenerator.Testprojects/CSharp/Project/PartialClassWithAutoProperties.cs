﻿
namespace Test
{
    public partial class PartialClassWithAutoProperties
    {
        public string Property1 { get; set; }
    }
}
