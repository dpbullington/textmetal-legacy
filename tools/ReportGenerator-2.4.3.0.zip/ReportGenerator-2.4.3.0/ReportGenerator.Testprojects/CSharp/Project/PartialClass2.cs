﻿using System;

namespace Test
{
    partial class PartialClass
    {
        public void ExecutedMethod_2()
        {
            Console.WriteLine("Test");
        }

        public void UnExecutedMethod_2()
        {
            Console.WriteLine("Test");
        }
    }
}
